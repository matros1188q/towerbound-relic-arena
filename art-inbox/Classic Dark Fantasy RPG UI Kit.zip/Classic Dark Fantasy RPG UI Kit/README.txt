================================================================================
CLASSIC DARK FANTASY RPG UI KIT
================================================================================

A complete dark fantasy RPG user interface kit featuring 114 RGBA PNG
assets, 98 editable SVG vector sources, bundled Cinzel & Crimson Text
fonts (SIL OFL 1.1), a ready-to-use Godot 4 Theme and demo HUD scene, and
universal 9-slice / cursor hotspot metadata.

Designed around deep obsidian slate wells, forged gunmetal bevels, antique
burnished brass trim, stitched parchment, title screen & dialog frames,
icon-ready skill tree nodes, loading bar, and layered crystal-domed resource globes.


================================================================================
SUPPORT & COMMUNITY
================================================================================

This pack is 100% free. If you find these assets helpful:

☕ Support me on Ko-fi: https://ko-fi.com/amompharetus
💬 Join my Discord server: https://discord.gg/bEqyjMat58


================================================================================
LICENSE: CC0 1.0 UNIVERSAL (PUBLIC DOMAIN)
================================================================================

This asset pack's UI graphics, SVG sources, 9-slice metadata, and Godot 4 theme
files are dedicated to the public domain under Creative Commons CC0 1.0.
You can copy, modify, distribute, and use these assets in personal and commercial
projects without asking for permission or paying royalties.

Attribution is not required, but appreciated!

Creative Commons Legal Code:
https://creativecommons.org/publicdomain/zero/1.0/

Note on /fonts/: Bundled font files (`Cinzel` and `Crimson Text`) are licensed
under the SIL Open Font License 1.1 (free for personal and commercial use). Full
license texts are included inside `/fonts/Cinzel-OFL.txt` and `/fonts/CrimsonText-OFL.txt`.


================================================================================
FOLDER STRUCTURE
================================================================================

1. /png/ (114 files)
   Clean transparent RGBA PNG assets grouped by UI function:
   - /windows_panels/   (10 files) : Stone, dark iron & parchment 9-slice panels,
                                  title screen frame, dialog frame, tooltip panel,
                                  header ribbon & ornate gold divider
   - /buttons_tabs/     (15 files): Primary, Crimson & Square buttons (4 states each)
                                  plus top navigation Tabs (active/hover/inactive)
   - /slots_inventory/  (27 files): 128x128 inventory slots (normal/hover/selected/locked),
                                  5 rarity borders, 3 status-effect frames, 9 equipment
                                  silhouettes & icon-ready skill tree nodes/links
   - /hud_bars_globes/  (26 files): Layered HP/Mana/Stamina/Gold orb parts & previews
                                  (sculpted 3D crystal dome + socket cavity), resource bar
                                  frames/fills, boss bar, endcaps, minimap frames/markers
                                  & radial cooldown overlay
   - /controls_widgets/ (31 files): Checkboxes, radio buttons, text inputs, dropdowns,
                                  loading bar, sliders, vertical scrollbars & 8 glyphs
   - /cursors/          (5 files) : 64x64 hardware mouse cursors with drop shadows

2. /svg/ (98 files)
   Editable vector source files (.svg) organized into matching subfolders. Open
   in Inkscape, Illustrator, Figma, or Affinity Designer to recolor, swap shapes,
   or export at 2x/4x high-DPI resolutions.

3. /fonts/ (6 files, SIL OFL 1.1)
   Bundled dark fantasy typography wired directly into the Godot 4 theme:
   - Cinzel[wght].ttf + Cinzel-OFL.txt (headings, buttons & tabs)
   - CrimsonText-Regular/SemiBold/Bold.ttf + CrimsonText-OFL.txt (UI body text)

4. /godot_theme/ (3 files)
   - classic_rpg_theme.tres    : Ready-to-use Godot 4 Theme resource mapping
                                 Panel, Button, CrimsonButton, DialogPanel,
                                 TitleScreenPanel, TitleLabel, ParchmentPanel,
                                 ParchmentLabel, LoadingBar, SkillNode* variants,
                                 TabContainer, TabBar, ProgressBar, HSlider,
                                 VScrollBar, CheckBox, LineEdit, OptionButton & PopupMenu
   - demo_hud.tscn             : Assembled 1920x1080 RPG HUD & skill tree showcase scene
   - theme_setup_notes.txt     : Quick-start guide for Godot 4 setup, variations & orbs

5. /metadata/ (1 file)
   - nine_slice_margins.json   : Machine-readable JSON listing exact image sizes,
                                 9-slice margins (L/T/R/B, Unity Sprite [L,B,R,T]
                                 borders, Unreal UMG normalized UV margins), cursor
                                 hotspots, bundled fonts, and canonical color hex codes

6. /previews/ (5 files)
   - hud_gameplay_mockup.png         : 1920x1080 HUD layout built strictly with kit assets
   - menus_and_skill_tree_preview.png: 1920x1080 menus, settings, dialog & skill tree screen
   - all_assets_preview.png          : Grouped overview sheet of all UI components
   - itch_cover_banner.png           : 1280x720 store cover banner
   - itch_card_thumbnail.png         : 630x500 store card thumbnail


================================================================================
9-SLICE MARGIN REFERENCE
================================================================================

All stretchable panels, buttons, tabs, bars, and slots share exact pixel margins
so brass corners and iron bevels never distort when resized:

  Asset Path                                             Size       Margin (L, T, R, B)  Unity [L,B,R,T]
  ------------------------------------------------------------------------------------------------------
  png/windows_panels/panel_stone_ornate.png              256x256    48, 48, 48, 48       [48, 48, 48, 48]
  png/windows_panels/title_screen_frame.png              512x320    72, 64, 72, 64       [72, 64, 72, 64]
  png/windows_panels/panel_iron_dark.png                 256x256    40, 40, 40, 40       [40, 40, 40, 40]
  png/windows_panels/panel_parchment_framed.png          256x256    48, 48, 48, 48       [48, 48, 48, 48]
  png/windows_panels/panel_parchment_clean.png           256x256    32, 32, 32, 32       [32, 32, 32, 32]
  png/windows_panels/panel_recessed_well.png             192x192    28, 28, 28, 28       [28, 28, 28, 28]
  png/windows_panels/panel_tooltip.png                   192x192    24, 24, 24, 24       [24, 24, 24, 24]
  png/windows_panels/header_ribbon_gold.png              384x80     84, 16, 84, 16       [84, 16, 84, 16]
  png/buttons_tabs/btn_primary_normal.png                256x72     24, 18, 24, 18       [24, 18, 24, 18]
  png/buttons_tabs/btn_primary_hover.png                 256x72     24, 18, 24, 18       [24, 18, 24, 18]
  png/buttons_tabs/btn_primary_pressed.png               256x72     24, 18, 24, 18       [24, 18, 24, 18]
  png/buttons_tabs/btn_primary_disabled.png              256x72     24, 18, 24, 18       [24, 18, 24, 18]
  png/buttons_tabs/btn_crimson_normal.png                256x72     24, 18, 24, 18       [24, 18, 24, 18]
  png/buttons_tabs/btn_crimson_hover.png                 256x72     24, 18, 24, 18       [24, 18, 24, 18]
  png/buttons_tabs/btn_crimson_pressed.png               256x72     24, 18, 24, 18       [24, 18, 24, 18]
  png/buttons_tabs/btn_crimson_disabled.png              256x72     24, 18, 24, 18       [24, 18, 24, 18]
  png/buttons_tabs/btn_square_normal.png                 80x80      18, 18, 18, 18       [18, 18, 18, 18]
  png/buttons_tabs/btn_square_hover.png                  80x80      18, 18, 18, 18       [18, 18, 18, 18]
  png/buttons_tabs/btn_square_pressed.png                80x80      18, 18, 18, 18       [18, 18, 18, 18]
  png/buttons_tabs/btn_square_disabled.png               80x80      18, 18, 18, 18       [18, 18, 18, 18]
  png/buttons_tabs/tab_active.png                        160x56     18, 16, 18, 8        [18, 8, 18, 16]
  png/buttons_tabs/tab_hover.png                         160x56     18, 16, 18, 8        [18, 8, 18, 16]
  png/buttons_tabs/tab_inactive.png                      160x56     18, 16, 18, 8        [18, 8, 18, 16]
  png/controls_widgets/slider_track.png                  192x24     12, 6, 12, 6         [12, 6, 12, 6]
  png/controls_widgets/slider_fill.png                   192x24     12, 6, 12, 6         [12, 6, 12, 6]
  png/controls_widgets/scrollbar_track_v.png             28x128     8, 12, 8, 12         [8, 12, 8, 12]
  png/controls_widgets/scrollbar_grabber_v.png           28x96      8, 12, 8, 12         [8, 12, 8, 12]
  png/controls_widgets/scrollbar_grabber_hover_v.png     28x96      8, 12, 8, 12         [8, 12, 8, 12]
  png/hud_bars_globes/bar_frame.png                      320x44     24, 10, 24, 10       [24, 10, 24, 10]
  png/hud_bars_globes/bar_track.png                      320x44     24, 10, 24, 10       [24, 10, 24, 10]
  png/hud_bars_globes/bar_fill_health.png                300x28     8, 6, 8, 6           [8, 6, 8, 6]
  png/hud_bars_globes/bar_fill_mana.png                  300x28     8, 6, 8, 6           [8, 6, 8, 6]
  png/hud_bars_globes/bar_fill_stamina.png               300x28     8, 6, 8, 6           [8, 6, 8, 6]
  png/hud_bars_globes/bar_fill_xp.png                    300x28     8, 6, 8, 6           [8, 6, 8, 6]
  png/hud_bars_globes/boss_bar_frame.png                 640x80     96, 22, 96, 22       [96, 22, 96, 22]
  png/slots_inventory/slot_normal.png                    128x128    18, 18, 18, 18       [18, 18, 18, 18]
  png/slots_inventory/slot_hover.png                     128x128    18, 18, 18, 18       [18, 18, 18, 18]
  png/slots_inventory/slot_selected.png                  128x128    18, 18, 18, 18       [18, 18, 18, 18]
  png/slots_inventory/slot_locked.png                    128x128    18, 18, 18, 18       [18, 18, 18, 18]
  png/windows_panels/dialog_frame.png                    384x192    40, 40, 40, 40       [40, 40, 40, 40]
  png/controls_widgets/loading_bar_track.png             480x36     14, 12, 14, 12       [14, 12, 14, 12]
  png/controls_widgets/loading_bar_fill.png              480x36     10, 8, 10, 8         [10, 8, 10, 8]
  png/controls_widgets/input_normal.png                  256x48     14, 14, 14, 14       [14, 14, 14, 14]
  png/controls_widgets/input_focus.png                   256x48     14, 14, 14, 14       [14, 14, 14, 14]
  png/controls_widgets/input_disabled.png                256x48     14, 14, 14, 14       [14, 14, 14, 14]
  png/controls_widgets/dropdown_normal.png               256x48     14, 14, 46, 14       [14, 14, 46, 14]
  png/controls_widgets/dropdown_hover.png                256x48     14, 14, 46, 14       [14, 14, 46, 14]
  png/controls_widgets/dropdown_pressed.png              256x48     14, 14, 46, 14       [14, 14, 46, 14]
  png/controls_widgets/dropdown_disabled.png             256x48     14, 14, 46, 14       [14, 14, 46, 14]


================================================================================
CURSOR HOTSPOTS (64x64)
================================================================================

  - png/cursors/cursor_gauntlet.png      (64x64)  hotspot: (8, 6)
  - png/cursors/cursor_sword.png         (64x64)  hotspot: (8, 8)
  - png/cursors/cursor_interact.png      (64x64)  hotspot: (22, 10)
  - png/cursors/cursor_spell.png         (64x64)  hotspot: (32, 32)
  - png/cursors/cursor_locked.png        (64x64)  hotspot: (32, 32)


================================================================================
BUNDLED FONTS (/fonts/ - SIL OFL 1.1)
================================================================================

Cinzel (`Cinzel[wght].ttf`) and Crimson Text (`CrimsonText-*.ttf`) are
included directly inside `/fonts/` with their `*-OFL.txt` license files and
pre-wired into `godot_theme/classic_rpg_theme.tres`.


================================================================================
ENGINE IMPORT NOTES
================================================================================

GODOT 4.x:
  Copy the entire `Classic Dark Fantasy RPG UI Kit` folder directly into your Godot
  project's `res://` directory, then apply `godot_theme/classic_rpg_theme.tres`
  to your root HUD Control or Project Settings -> GUI -> Theme -> Custom.
  See `godot_theme/theme_setup_notes.txt` for layered orb & variation details.

UNITY (UGUI / UI TOOLKIT):
  Import `/png/` textures with Texture Type = Sprite (2D and UI), Mesh Type =
  Full Rect, and enter the `Unity [L, B, R, T]` border values from the table
  above inside the Sprite Editor -> Border fields, then set Image Type = Sliced.

UNREAL ENGINE (UMG):
  Set Draw As = Box in Brush settings and divide each pixel margin by the texture's
  width/height (or copy normalized UV margins) to lock beveled brass corners.

================================================================================
Enjoy building your RPG!
- Amompharetus
================================================================================
